package be.technifutur.jasa.rdf.TestSonarCloudDirtyProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSonarCloudDirtyProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSonarCloudDirtyProjectApplication.class, args);
	}

}
